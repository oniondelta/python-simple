

with open("cpy.txt",mode="r",encoding="utf-8") as infile:
    wc=infile.read()

import re

#檢查是否有錯碼
pattern=re.compile(r'[\d][\d]')
search=pattern.search(wc)
if search:
    print("《錯碼！》有〔數字〕重複兩個以上",search)
else:
    print("《正確！》無〔數字〕重複兩個以上")
pattern=re.compile(r'^[\d]|[\n][\d]')
search=pattern.search(wc)
if search:
    print("《錯碼！》有〔數字〕在行首",search)
else:
    print("《正確！》無〔數字〕在行首")
pattern=re.compile(r'\s\d')
search=pattern.search(wc)
if search:
    print("《錯碼！》有〔數字〕前面接空格或換行符",search)
else:
    print("《正確！》無〔數字〕前面接空格或換行符")
pattern=re.compile(r'[^a-z0-9\s][a-z0-9]|[a-z0-9][^a-z0-9\s]')
search=pattern.search(wc)
if search:
    print("《錯碼！》有〔數字〕〔英文〕前後接其他字符",search)
else:
    print("《正確！》無〔數字〕〔英文〕前後接其他字符")
pattern=re.compile(r'[a-z]\s')
search=pattern.search(wc)
if search:
    print("《錯碼！》有〔英文〕後接空格或換行符",search)
else:
    print("《正確！》無〔英文〕後接空格或換行符")
pattern=re.compile(r'[bpmfdtlgkhjqxryw][bpmfdtnlgkhjqxzcsryw]|n[bpmfdtnlkhjqxzcsryw]|[zcs][bpmfdtnlgkjqxzcsryw]|[bpmf][v]|bou|[bpmf]e[hr]|fai|fon|no[abcdefghijklmopqrstvwxyz]|[dt]v|[dtnl]e[hr]|do[abcdefghijklmopqrstvwxyz]|g[iv]|k[iv]|[kg]o[abcdefghijklmopqrstvwxyz]|h[v]|[gkh]e[hr]|kei|x[aoe]|[jq][aoe]|[zcsr][h]?[v]|[zcsr][h]?[e][r]|an[abcdefhijklmnopqrstuvwxyz]|ya[abcdefghjklmpqrstuvwxyz]|a[abcdefghjklmpqrstuvwxyz]|ye[ihnr]|e[abcdefgjklmopqstuvwxyz]|yi[euao]|i[bpmfdtlgkhjqxzcsriv]|in[abcdefhijklmnopqrstuvwxyz]|o[bpmfdtlgkhjqxzcsrivaoe]|on[abcdefhijklmnopqrstuvwxyz]|yu[io]|u[bpmfdtlgkhjqxzcsruv]|un[abcdefhijklmnopqrstuvwsyz]|vv|weh|en[abcdefhijklmnopqrstuvwxyz]|w[io][a-z]')
search=pattern.search(wc)
if search:
    print("《錯碼！》有錯誤的〔拼音〕一",search)
else:
    print("《正確！》無錯誤的〔拼音〕一")
pattern=re.compile(r'[bpmfdtlgkhjqxryiwuvoa][bpmfdtlgkhjqxzcsryw]|[bpmfdtnlgkhjqxzcsrywv][n]|[zsce][bpmfdtlgkjqxzcsywv]|[gkiwvo][i]|[zsc][r]')
search=pattern.search(wc)
if search:
    print("《錯碼！》有錯誤的〔拼音〕二",search)
else:
    print("《正確！》無錯誤的〔拼音〕二")

