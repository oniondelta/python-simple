

#with open("input_pinyin.txt",mode="r",encoding="utf-8") as infile:
#    word=infile.read()

import re
word='''
yī liù
yī liè
yī gāng
yī jiàn
yī jié
yī sháo
sháo yì
yī shí
wo shì
gao
lüè
le
yuè
nǚ
lú
lǚ
lü
lüe
gu
gv

'''

w1=re.sub(r"([a-zü]*)ī([a-zü]*)",r"\1i\2@",word)
w2=re.sub(r"([a-zü]*)ū([a-zü]*)",r"\1u\2@",w1)
w3=re.sub(r"([a-zü]*)ē([a-zü]*)",r"\1e\2@",w2)
w4=re.sub(r"([a-zü]*)ō([a-zü]*)",r"\1o\2@",w3)
w5=re.sub(r"([a-zü]*)ā([a-zü]*)",r"\1a\2@",w4)

w6=re.sub(r"([a-zü]*)í([a-zü]*)",r"\1i\2@@",w5)
w7=re.sub(r"([a-zü]*)ú([a-zü]*)",r"\1u\2@@",w6)
w8=re.sub(r"([a-zü]*)é([a-zü]*)",r"\1e\2@@",w7)
w9=re.sub(r"([a-zü]*)ó([a-zü]*)",r"\1o\2@@",w8)
w10=re.sub(r"([a-zü]*)á([a-zü]*)",r"\1a\2@@",w9)

w11=re.sub(r"([a-zü]*)ǐ([a-zü]*)",r"\1i\2@@@",w10)
w12=re.sub(r"([a-zü]*)ǔ([a-zü]*)",r"\1u\2@@@",w11)
w13=re.sub(r"([a-zü]*)ě([a-zü]*)",r"\1e\2@@@",w12)
w14=re.sub(r"([a-zü]*)ǒ([a-zü]*)",r"\1o\2@@@",w13)
w15=re.sub(r"([a-zü]*)ǎ([a-zü]*)",r"\1a\2@@@",w14)

w16=re.sub(r"([a-zü]*)ì([a-zü]*)",r"\1i\2@@@@",w15)
w17=re.sub(r"([a-zü]*)ù([a-zü]*)",r"\1u\2@@@@",w16)
w18=re.sub(r"([a-zü]*)è([a-zü]*)",r"\1e\2@@@@",w17)
w19=re.sub(r"([a-zü]*)ò([a-zü]*)",r"\1o\2@@@@",w18)
w20=re.sub(r"([a-zü]*)à([a-zü]*)",r"\1a\2@@@@",w19)

w21=re.sub(r"([a-z]*)ǘ([a-z]*)",r"\1v\2@@",w20)
w22=re.sub(r"([a-z]*)ǚ([a-z]*)",r"\1v\2@@@",w21)
w23=re.sub(r"([a-z]*)ǜ([a-z]*)",r"\1v\2@@@@",w22)

w24=re.sub(r"ü",r"v",w23)

w25=re.sub(r"([a-z]+)(\s)",r"\1@@@@@\2",w24)
w26=re.sub(r"@@@@@",r"5",w25)
w27=re.sub(r"@@@@",r"4",w26)
w28=re.sub(r"@@@",r"3",w27)
w29=re.sub(r"@@",r"2",w28)
w30=re.sub(r"@",r"1",w29)

print(w1)

#with open("output_pinyin.txt",mode="w",encoding="utf-8") as outfile:
#    outfile.write(w30)


